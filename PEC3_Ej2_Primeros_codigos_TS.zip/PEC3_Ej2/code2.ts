const a = 1042;
const b = 'apples and oranges';
const c = 'pineapples';
const d = [true, true, false];
const e = { type: 'ficus' };
const f = [1, false];
const g = [3];
const h = null;
